?package(ubucompilator):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="ubucompilator" command="/usr/bin/ubucompilator"
